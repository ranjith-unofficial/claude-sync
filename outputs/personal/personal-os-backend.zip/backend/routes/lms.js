const express = require('express');
const router = express.Router();
const {
  LMS_DB_PATH,
  getLocalData,
  saveLocalData,
  requireAdmin
} = require('../lib/helpers');

router.get('/lms/users', requireAdmin, (req, res) => {
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [] });
  res.json(data.users);
});

router.post('/lms/users', requireAdmin, (req, res) => {
  const { name, email, role, password } = req.body;
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [] });
  const newUser = { id: Date.now(), name, email, role, password, created_at: new Date().toISOString() };
  data.users.push(newUser);
  saveLocalData(LMS_DB_PATH, data);
  res.status(201).json(newUser);
});

router.get('/lms/courses', (req, res) => {
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [] });
  res.json(data.courses);
});

router.post('/lms/courses', requireAdmin, (req, res) => {
  const { title, category, description, modules } = req.body;
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [] });
  const newCourse = { id: Date.now(), title, category, description, modules: modules || [], published: true, created_at: new Date().toISOString() };
  data.courses.push(newCourse);
  saveLocalData(LMS_DB_PATH, data);
  res.status(201).json(newCourse);
});

router.get('/lms/submissions', (req, res) => {
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [], submissions: [] });
  res.json(data.submissions || []);
});

router.post('/lms/submissions', (req, res) => {
  const { courseId, courseTitle, studentEmail, url, notes } = req.body;
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [], submissions: [] });
  if (!data.submissions) data.submissions = [];
  const sub = {
    id: Date.now().toString(),
    courseId,
    courseTitle: courseTitle || "Untitled Course",
    studentEmail: studentEmail || "student@ranjith.tech",
    url: url || "",
    notes: notes || "",
    status: "pending",
    created_at: new Date().toISOString()
  };
  data.submissions.unshift(sub);
  saveLocalData(LMS_DB_PATH, data);
  res.status(201).json(sub);
});

router.patch('/lms/submissions/:id', (req, res) => {
  const { status } = req.body;
  const data = getLocalData(LMS_DB_PATH, { users: [], courses: [], submissions: [] });
  if (!data.submissions) data.submissions = [];
  const sub = data.submissions.find(s => String(s.id) === String(req.params.id));
  if (sub) {
    sub.status = status;
    saveLocalData(LMS_DB_PATH, data);
    return res.json(sub);
  }
  res.status(404).json({ error: "Submission not found" });
});

module.exports = router;
