const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const {
  logSecurityEvent,
  checkBruteForce,
  recordFailedAttempt,
  resetFailedAttempts,
  getRecoveryKey,
  getAdminPasscode,
  hashPassword,
  getMasterPasswordHash,
  safeCompare,
  rateLimit,
  activeAdminTokens
} = require('../lib/helpers');

// Sits in front of the existing 3-strike lockout: the lockout stops guessing,
// this stops flooding the endpoint from many angles at once.
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, name: 'admin-auth' });

router.post('/emergency-unlock', authLimiter, (req, res) => {
  const clientIP = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const { recoveryKey } = req.body;
  const configuredKey = getRecoveryKey();
  if (!configuredKey) {
    logSecurityEvent('EMERGENCY_RECOVERY_UNCONFIGURED', clientIP, 'EMERGENCY_RECOVERY_KEY is not set.');
    return res.status(503).json({ error: 'Emergency recovery is not configured on this server.' });
  }
  if (recoveryKey && safeCompare(recoveryKey, configuredKey)) {
    logSecurityEvent('EMERGENCY_RECOVERY_SUCCESS', clientIP, 'Master recovery key accepted.');
    const tempToken = crypto.randomBytes(32).toString('hex');
    activeAdminTokens.set(tempToken, { createdAt: Date.now(), ip: clientIP });
    return res.json({ success: true, token: tempToken });
  }
  return res.status(401).json({ error: 'Invalid recovery key.' });
});

router.post('/login', authLimiter, (req, res) => {
  const clientIP = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const brute = checkBruteForce(clientIP);
  if (!brute.allowed) {
    return res.status(429).json({ error: `Too many attempts. Locked out for ${brute.remainingSec}s.` });
  }

  const { passcode } = req.body;
  if (!passcode || typeof passcode !== 'string') {
    recordFailedAttempt(clientIP);
    return res.status(400).json({ error: 'Security passcode required.' });
  }

  const inputHash = hashPassword(passcode);
  if (safeCompare(inputHash, getMasterPasswordHash()) || safeCompare(passcode, getAdminPasscode())) {
    resetFailedAttempts(clientIP);
    const token = crypto.randomBytes(32).toString('hex');
    activeAdminTokens.set(token, { createdAt: Date.now(), ip: clientIP });
    logSecurityEvent('ADMIN_LOGIN_SUCCESS', clientIP, 'Successful login.');
    return res.json({ success: true, token });
  }

  const record = recordFailedAttempt(clientIP);
  logSecurityEvent('ADMIN_LOGIN_FAILED', clientIP, `Invalid passcode. Attempt ${record.count}/3`);
  return res.status(401).json({ error: 'Invalid security passcode.' });
});

router.get('/me', (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/, '') || req.headers['x-admin-passcode'];
  if (token && activeAdminTokens.has(token)) {
    return res.json({ authenticated: true, role: 'master_admin' });
  }
  if (token && (safeCompare(token, getAdminPasscode()) || safeCompare(hashPassword(token), getMasterPasswordHash()))) {
    return res.json({ authenticated: true, role: 'master_admin' });
  }
  return res.json({ authenticated: false });
});

router.post('/logout', (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/, '') || req.headers['x-admin-passcode'];
  if (token && activeAdminTokens.has(token)) {
    activeAdminTokens.delete(token);
  }
  res.json({ success: true });
});

module.exports = router;
