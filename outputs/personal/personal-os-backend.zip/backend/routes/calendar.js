const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const {
  isDateString,
  requireAdmin,
  logSecurityEvent
} = require('../lib/helpers');
const {
  configStatus,
  buildAuthUrl,
  exchangeCodeForTokens,
  fetchRange,
  fetchToday
} = require('../lib/calendar');

router.get('/calendar/status', requireAdmin, (req, res) => {
  const status = configStatus();
  res.json({ connected: status.ok, reason: status.reason || null, needsConsent: Boolean(status.needsConsent) });
});

router.get('/calendar/today', requireAdmin, async (req, res) => {
  res.json(await fetchToday());
});

router.get('/calendar/range', requireAdmin, async (req, res) => {
  const { from, to } = req.query;
  if (!isDateString(from) || !isDateString(to)) {
    return res.status(400).json({ error: 'from and to are required as YYYY-MM-DD.' });
  }
  if (from > to) {
    return res.status(400).json({ error: 'from must not be after to.' });
  }
  res.json(await fetchRange(from, to));
});

// --- OAuth consent flow ---------------------------------------------------
// One-time, run from a browser while logged into the admin.

const pendingStates = new Map();
const STATE_TTL_MS = 10 * 60 * 1000;

router.get('/calendar/oauth/start', requireAdmin, (req, res) => {
  const status = configStatus();
  if (!status.ok && !status.needsConsent) {
    return res.status(503).json({ error: status.reason });
  }
  const state = crypto.randomBytes(16).toString('hex');
  pendingStates.set(state, Date.now() + STATE_TTL_MS);
  res.json({ authUrl: buildAuthUrl(state) });
});

// Google redirects here. No requireAdmin: the browser arrives without the
// bearer header, so the CSRF `state` issued above is what authenticates it.
router.get('/calendar/oauth/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) return res.status(400).send(`Google authorisation failed: ${error}`);
  if (!code || !state) return res.status(400).send('Missing code or state.');

  const expiry = pendingStates.get(state);
  pendingStates.delete(state);
  if (!expiry || Date.now() > expiry) {
    logSecurityEvent('CALENDAR_OAUTH_BAD_STATE', req.ip, 'Unknown or expired OAuth state.');
    return res.status(400).send('Invalid or expired authorisation state. Start again from the admin.');
  }

  try {
    await exchangeCodeForTokens(code);
    logSecurityEvent('CALENDAR_OAUTH_CONNECTED', req.ip, 'Google Calendar refresh token stored.');
    res.send('<h2>Google Calendar connected.</h2><p>You can close this tab and refresh the Personal OS dashboard.</p>');
  } catch (err) {
    console.error('[calendar] token exchange failed:', err.message);
    res.status(502).send(`Token exchange failed: ${err.message}`);
  }
});

module.exports = router;
