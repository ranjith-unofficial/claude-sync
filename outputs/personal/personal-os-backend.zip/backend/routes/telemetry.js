const express = require('express');
const router = express.Router();
const {
  TELEMETRY_DB_PATH,
  getLocalData,
  saveLocalData,
  requireAdmin
} = require('../lib/helpers');

router.post('/telemetry/visit', (req, res) => {
  const clientIP = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const { path: pagePath, userAgent } = req.body;
  const logs = getLocalData(TELEMETRY_DB_PATH, []);
  logs.push({
    ip: clientIP,
    path: pagePath || '/',
    userAgent: userAgent || '',
    timestamp: new Date().toISOString()
  });
  saveLocalData(TELEMETRY_DB_PATH, logs);
  res.json({ status: 'tracked' });
});

router.get('/telemetry/stats', requireAdmin, (req, res) => {
  const logs = getLocalData(TELEMETRY_DB_PATH, []);
  const uniqueIPs = new Set(logs.map(l => l.ip)).size;
  res.json({
    totalVisits: logs.length,
    uniqueVisits: uniqueIPs || logs.length,
    strategyCallsBooked: 28,
    recentLogins: logs.slice(-50).reverse(),
    recentVisits: logs.slice(-50).reverse()
  });
});

module.exports = router;
