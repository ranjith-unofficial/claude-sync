const express = require('express');
const axios = require('axios');
const router = express.Router();
const {
  HEALTH_DB_PATH,
  WORKOUT_DB_PATH,
  METRICS_DB_PATH,
  FOOD_DB_PATH,
  getLocalData,
  saveLocalData,
  istToday,
  normalizeDate,
  isDateString,
  requireAdmin
} = require('../lib/helpers');
const {
  DEFAULT_TARGETS,
  readTargets,
  readFoodDay,
  appendMeals,
  sumMeals,
  progressAgainstTargets
} = require('../lib/nutrition');

// Seed health_metrics.json with July 21, 2026 Smart Scale reading if empty
const seedHealthMetricsIfEmpty = () => {
  const current = getLocalData(METRICS_DB_PATH, []);
  if (current.length === 0) {
    const seedEntry = {
      id: 1784688000000,
      date: "2026-07-21T08:00:00.000Z",
      weight: 94.35,
      bmi: 35.10,
      bodyFat: 34.3,
      visceralFat: 17.0,
      muscleMass: 58.9,
      bmr: 1708,
      source: "Smart Scale Reading"
    };
    saveLocalData(METRICS_DB_PATH, [seedEntry]);
  }
};
seedHealthMetricsIfEmpty();

router.post('/workouts/sets', requireAdmin, (req, res) => {
  const { splitName, exercises, descriptionNotes, date } = req.body;
  const logs = getLocalData(WORKOUT_DB_PATH, []);
  const entry = {
    id: Date.now(),
    // IST, not UTC: an evening session in India was being stamped with the
    // previous day and never counted as "today" on the dashboard.
    date: normalizeDate(date),
    splitName,
    exercises,
    descriptionNotes: descriptionNotes || "",
    timestamp: new Date().toISOString()
  };
  logs.unshift(entry);
  saveLocalData(WORKOUT_DB_PATH, logs);
  res.json({ success: true, entry });
});

router.get('/workouts/history', requireAdmin, (req, res) => {
  res.json(getLocalData(WORKOUT_DB_PATH, []));
});

// Personal biometrics — admin only. This used to be public.
router.get('/health/dashboard', requireAdmin, (req, res) => {
  const healthData = getLocalData(HEALTH_DB_PATH, {});
  const date = istToday();
  const targets = readTargets();
  const totals = sumMeals(readFoodDay(date)?.meals);

  res.json({
    date,
    oura: healthData.oura || { synced: false, reason: 'Never synced.' },
    targets,
    nutrition: { totals, progress: progressAgainstTargets(totals, targets) }
  });
});

router.get('/health/targets', requireAdmin, (req, res) => {
  res.json(readTargets());
});

router.post('/health/targets', requireAdmin, (req, res) => {
  const { calories, protein, carbs, fats } = req.body;
  const healthData = getLocalData(HEALTH_DB_PATH, {});
  const newTargets = {
    calories: parseInt(calories, 10) || DEFAULT_TARGETS.calories,
    protein: parseInt(protein, 10) || DEFAULT_TARGETS.protein,
    carbs: parseInt(carbs, 10) || DEFAULT_TARGETS.carbs,
    fats: parseInt(fats, 10) || DEFAULT_TARGETS.fats
  };
  healthData.targets = newTargets;
  healthData.nutrition = newTargets;
  saveLocalData(HEALTH_DB_PATH, healthData);
  res.json({ success: true, targets: newTargets });
});

// Pulls real Oura data or reports why it could not. Never invents scores, and
// merges into the health record so nutrition targets survive a sync.
const syncOura = async (date) => {
  const token = process.env.OURA_PERSONAL_ACCESS_TOKEN;
  const checked_at = new Date().toISOString();

  if (!token) {
    return { synced: false, reason: 'OURA_PERSONAL_ACCESS_TOKEN is not configured on the server.', checked_at };
  }

  const headers = { Authorization: `Bearer ${token}` };
  const query = `start_date=${date}&end_date=${date}`;
  let readinessRes;
  let sleepRes;
  let activityRes;

  try {
    [readinessRes, sleepRes, activityRes] = await Promise.all([
      axios.get(`https://api.ouraring.com/v2/usercollection/daily_readiness?${query}`, { headers, timeout: 12000 }),
      axios.get(`https://api.ouraring.com/v2/usercollection/daily_sleep?${query}`, { headers, timeout: 12000 }),
      axios.get(`https://api.ouraring.com/v2/usercollection/daily_activity?${query}`, { headers, timeout: 12000 })
    ]);
  } catch (err) {
    const status = err.response?.status;
    const reason = status === 401
      ? 'Oura rejected the access token (401). Regenerate OURA_PERSONAL_ACCESS_TOKEN.'
      : `Oura API request failed${status ? ` (${status})` : ''}: ${err.message}`;
    return { synced: false, reason, checked_at };
  }

  const readiness = readinessRes.data?.data?.[0];
  const sleep = sleepRes.data?.data?.[0];
  const activity = activityRes.data?.data?.[0];

  if (!readiness && !sleep && !activity) {
    return { synced: false, reason: `Oura has no data for ${date} yet.`, checked_at, date };
  }

  // null, not a placeholder number — the UI renders "--" for missing scores.
  return {
    synced: true,
    date,
    readiness: readiness?.score ?? null,
    sleep: sleep?.score ?? null,
    activity: activity?.score ?? null,
    hrv: readiness?.contributors?.hrv_balance ?? null,
    restingHeartRate: readiness?.contributors?.resting_heart_rate ?? null,
    activeCalories: activity?.active_calories ?? null,
    steps: activity?.steps ?? null,
    checked_at,
    last_synced: checked_at
  };
};

const handleOuraSync = async (req, res) => {
  const date = normalizeDate(req.query.date || req.body?.date);
  const result = await syncOura(date);
  const healthData = getLocalData(HEALTH_DB_PATH, {});
  healthData.oura = result;
  saveLocalData(HEALTH_DB_PATH, healthData);
  res.json(result);
};

router.post('/health/oura/sync', requireAdmin, handleOuraSync);
// GET form so a cron/agent can trigger the morning sync with a bearer token.
router.get('/health/oura/sync', requireAdmin, handleOuraSync);

router.get('/health/metrics', requireAdmin, (req, res) => {
  const metrics = getLocalData(METRICS_DB_PATH, []);
  res.json(metrics);
});

router.post('/health/metrics', requireAdmin, (req, res) => {
  const { weight, bodyFat, bmi, visceralFat, muscleMass, bmr } = req.body;
  if (!weight) return res.status(400).json({ error: 'Weight is required' });
  
  const metrics = getLocalData(METRICS_DB_PATH, []);
  const newEntry = {
    id: Date.now(),
    // Anchored to the IST day so charts and the seed entry share one format.
    date: `${istToday()}T00:00:00.000Z`,
    recordedAt: new Date().toISOString(),
    weight: parseFloat(weight),
    bodyFat: bodyFat ? parseFloat(bodyFat) : null,
    bmi: bmi ? parseFloat(bmi) : null,
    visceralFat: visceralFat ? parseFloat(visceralFat) : null,
    muscleMass: muscleMass ? parseFloat(muscleMass) : null,
    bmr: bmr ? parseFloat(bmr) : null
  };
  
  metrics.unshift(newEntry);
  saveLocalData(METRICS_DB_PATH, metrics);
  res.status(201).json(newEntry);
});

// --- Food log -------------------------------------------------------------
// Written by the admin UI and by external logging agents via /api/ingest.

router.get('/health/food/today', requireAdmin, (req, res) => {
  const date = istToday();
  const record = readFoodDay(date);
  const targets = readTargets();
  const totals = sumMeals(record?.meals);
  res.json({
    date,
    meals: record?.meals || [],
    totals,
    targets,
    progress: progressAgainstTargets(totals, targets)
  });
});

router.get('/health/food', requireAdmin, (req, res) => {
  const { from, to } = req.query;
  let log = getLocalData(FOOD_DB_PATH, []);
  if (isDateString(from)) log = log.filter((entry) => entry.date >= from);
  if (isDateString(to)) log = log.filter((entry) => entry.date <= to);
  res.json(log.map((entry) => ({ ...entry, totals: sumMeals(entry.meals) })));
});

router.post('/health/food', requireAdmin, (req, res) => {
  const { date, meals, source } = req.body;
  if (!Array.isArray(meals) || meals.length === 0) {
    return res.status(400).json({ error: 'meals must be a non-empty array.' });
  }
  const { record, added } = appendMeals(date, meals, source);
  const targets = readTargets();
  const totals = sumMeals(record.meals);
  res.status(201).json({
    success: true,
    date: record.date,
    added,
    totals,
    targets,
    progress: progressAgainstTargets(totals, targets)
  });
});

router.delete('/health/food/:date/meals/:mealId', requireAdmin, (req, res) => {
  const { date, mealId } = req.params;
  const log = getLocalData(FOOD_DB_PATH, []);
  const record = log.find((entry) => entry.date === date);
  if (!record) return res.status(404).json({ error: 'No food logged for that date.' });

  const remaining = record.meals.filter((meal) => meal.id !== mealId);
  if (remaining.length === record.meals.length) {
    return res.status(404).json({ error: 'Meal not found.' });
  }
  record.meals = remaining;
  record.updatedAt = new Date().toISOString();
  saveLocalData(FOOD_DB_PATH, log);
  res.json({ success: true, date, totals: sumMeals(record.meals) });
});

module.exports = router;
