const express = require('express');
const router = express.Router();
const {
  INVOICES_DB_PATH,
  getLocalData,
  saveLocalData,
  requireAdmin
} = require('../lib/helpers');

router.get('/invoices', requireAdmin, (req, res) => {
  res.json(getLocalData(INVOICES_DB_PATH, []));
});

router.post('/invoices', requireAdmin, (req, res) => {
  const invoiceData = req.body;
  if (!invoiceData.invoiceId) {
    const year = new Date().getFullYear();
    const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
    invoiceData.invoiceId = `RT-${year}-${randomStr}`;
  }
  const locals = getLocalData(INVOICES_DB_PATH, []);
  locals.unshift({ _id: Date.now().toString(), ...invoiceData, created_at: new Date() });
  saveLocalData(INVOICES_DB_PATH, locals);
  res.status(201).json(invoiceData);
});

module.exports = router;
