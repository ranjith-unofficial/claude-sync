const express = require('express');
const router = express.Router();
const {
  TASKS_DB_PATH,
  getLocalData,
  saveLocalData,
  isDateString,
  requireAdmin
} = require('../lib/helpers');
const {
  TASK_TYPES,
  PRIORITIES,
  STATUSES,
  oneOf,
  normalizeTimeOfDay,
  listTasks,
  addTask
} = require('../lib/day');

router.get('/day/tasks', requireAdmin, (req, res) => {
  const { date, from, to, status } = req.query;
  res.json(listTasks({ date, from, to, status: oneOf(status, STATUSES, null) }));
});

router.post('/day/tasks', requireAdmin, (req, res) => {
  if (!req.body || typeof req.body.title !== 'string' || !req.body.title.trim()) {
    return res.status(400).json({ error: 'title is required.' });
  }
  res.status(201).json(addTask(req.body));
});

router.patch('/day/tasks/:id', requireAdmin, (req, res) => {
  const tasks = getLocalData(TASKS_DB_PATH, []);
  const task = tasks.find((entry) => entry.id === req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found.' });

  const { title, type, priority, status, date, startsAt, endsAt, dueAt, notes } = req.body || {};
  if (typeof title === 'string' && title.trim()) task.title = title.trim();
  if (type !== undefined) task.type = oneOf(type, TASK_TYPES, task.type);
  if (priority !== undefined) task.priority = oneOf(priority, PRIORITIES, task.priority);
  if (status !== undefined) {
    task.status = oneOf(status, STATUSES, task.status);
    task.completedAt = task.status === 'complete' ? new Date().toISOString() : null;
  }
  if (isDateString(date)) task.date = date;
  if (startsAt !== undefined) task.startsAt = normalizeTimeOfDay(startsAt);
  if (endsAt !== undefined) task.endsAt = normalizeTimeOfDay(endsAt);
  if (dueAt !== undefined) task.dueAt = typeof dueAt === 'string' ? dueAt : null;
  if (typeof notes === 'string') task.notes = notes;
  task.updatedAt = new Date().toISOString();

  saveLocalData(TASKS_DB_PATH, tasks);
  res.json(task);
});

router.delete('/day/tasks/:id', requireAdmin, (req, res) => {
  const tasks = getLocalData(TASKS_DB_PATH, []);
  const remaining = tasks.filter((entry) => entry.id !== req.params.id);
  if (remaining.length === tasks.length) return res.status(404).json({ error: 'Task not found.' });
  saveLocalData(TASKS_DB_PATH, remaining);
  res.json({ success: true });
});

module.exports = router;
