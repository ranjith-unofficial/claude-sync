const express = require('express');
const router = express.Router();
const {
  SHORTENER_DB_PATH,
  getLocalData,
  saveLocalData,
  requireAdmin
} = require('../lib/helpers');

router.post('/shortener', requireAdmin, (req, res) => {
  const { code, target } = req.body;
  if (!code || !target) return res.status(400).json({ error: 'Code and target required' });
  const links = getLocalData(SHORTENER_DB_PATH, []);
  if (links.some(l => l.code === code.toLowerCase())) {
    return res.status(400).json({ error: 'Code already exists' });
  }
  const newLink = { code: code.toLowerCase(), target, clicks: 0, created_at: new Date().toISOString() };
  links.unshift(newLink);
  saveLocalData(SHORTENER_DB_PATH, links);
  res.status(201).json(newLink);
});

router.get('/shortener/:code', (req, res) => {
  const links = getLocalData(SHORTENER_DB_PATH, []);
  const link = links.find(l => l.code === req.params.code.toLowerCase());
  if (link) {
    link.clicks = (link.clicks || 0) + 1;
    saveLocalData(SHORTENER_DB_PATH, links);
    return res.json(link);
  }
  res.status(404).json({ error: 'Short link not found' });
});

const redirectByCode = (req, res, next) => {
  const links = getLocalData(SHORTENER_DB_PATH, []);
  const link = links.find(l => l.code === req.params.code.toLowerCase());
  if (link && link.target) {
    link.clicks = (link.clicks || 0) + 1;
    saveLocalData(SHORTENER_DB_PATH, links);
    return res.redirect(302, link.target);
  }
  next();
};

// Canonical short-link form. The previous production API served /s/:code, and
// links already in the wild use it — the bare /:code form is kept for
// backwards compatibility.
router.get('/s/:code', redirectByCode);
router.get('/:code', redirectByCode);

router.get('/admin/shortener', requireAdmin, (req, res) => {
  res.json(getLocalData(SHORTENER_DB_PATH, []));
});

module.exports = router;
