// One call that backs the Home — Today screen, so the dashboard does not fan
// out to six endpoints on load.
const express = require('express');
const router = express.Router();
const {
  HEALTH_DB_PATH,
  WORKOUT_DB_PATH,
  METRICS_DB_PATH,
  SHORTENER_DB_PATH,
  INVOICES_DB_PATH,
  TELEMETRY_DB_PATH,
  getLocalData,
  istToday,
  normalizeDate,
  TIMEZONE,
  requireAdmin
} = require('../lib/helpers');
const { readTargets, readFoodDay, sumMeals, progressAgainstTargets } = require('../lib/nutrition');
const { listTasks } = require('../lib/day');
const { listItems } = require('../lib/content');
const { fetchRange } = require('../lib/calendar');

const SPARK_POINTS = 14;

router.get('/home/today', requireAdmin, async (req, res) => {
  const date = normalizeDate(req.query.date);
  const isToday = date === istToday();

  // --- Health
  const healthData = getLocalData(HEALTH_DB_PATH, {});
  const metrics = getLocalData(METRICS_DB_PATH, []);
  const workouts = getLocalData(WORKOUT_DB_PATH, []);

  // metrics are stored newest-first; the sparkline wants oldest -> newest.
  const trend = metrics
    .slice(0, SPARK_POINTS)
    .map((m) => ({ date: (m.date || '').split('T')[0], weight: m.weight }))
    .filter((m) => typeof m.weight === 'number')
    .reverse();

  const latest = metrics[0] || null;
  const baseline = metrics.length > 1 ? metrics[metrics.length - 1] : null;

  const workoutToday = workouts.find((w) => w.date === date) || null;
  const lastWorkout = workouts[0] || null;

  const targets = readTargets();
  const foodRecord = readFoodDay(date);
  const totals = sumMeals(foodRecord?.meals);

  // --- Day + content
  const tasks = listTasks({ date });
  const contentItems = listItems({ date });

  // --- Ops counters (secondary, but keeps the tools from feeling orphaned)
  const shortlinks = getLocalData(SHORTENER_DB_PATH, []);
  const invoices = getLocalData(INVOICES_DB_PATH, []);
  const telemetry = getLocalData(TELEMETRY_DB_PATH, []);

  // Calendar is the only network call on this route; a failure must not take
  // the whole dashboard down, so fetchRange resolves to a reason instead.
  const calendar = await fetchRange(date, date);

  res.json({
    date,
    isToday,
    timezone: TIMEZONE,
    oura: healthData.oura || { synced: false, reason: 'Never synced.' },
    weight: {
      latest: latest ? { weight: latest.weight, date: (latest.date || '').split('T')[0] } : null,
      deltaFromBaseline: latest && baseline ? Number((latest.weight - baseline.weight).toFixed(2)) : null,
      readings: metrics.length,
      trend
    },
    workout: {
      status: workoutToday ? 'done' : 'planned',
      today: workoutToday
        ? {
            splitName: workoutToday.splitName,
            exercises: (workoutToday.exercises || []).length,
            sets: (workoutToday.exercises || []).reduce((sum, ex) => sum + (ex.sets || []).length, 0)
          }
        : null,
      last: lastWorkout ? { date: lastWorkout.date, splitName: lastWorkout.splitName } : null
    },
    nutrition: {
      targets,
      totals,
      progress: progressAgainstTargets(totals, targets),
      mealCount: foodRecord?.meals?.length || 0
    },
    tasks: {
      open: tasks.filter((t) => t.status === 'open').length,
      complete: tasks.filter((t) => t.status === 'complete').length,
      items: tasks,
      blocks: tasks.filter((t) => t.startsAt).sort((a, b) => a.startsAt.localeCompare(b.startsAt))
    },
    calendar,
    content: {
      drafts: contentItems.filter((c) => c.status === 'draft').length,
      ready: contentItems.filter((c) => c.status === 'ready').length,
      posted: contentItems.filter((c) => c.status === 'posted').length,
      items: contentItems
    },
    ops: {
      shortlinks: shortlinks.length,
      invoices: Array.isArray(invoices) ? invoices.length : 0,
      visitsLogged: Array.isArray(telemetry) ? telemetry.length : 0
    }
  });
});

module.exports = router;
