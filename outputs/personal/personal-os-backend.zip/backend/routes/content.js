const express = require('express');
const router = express.Router();
const {
  CONTENT_DB_PATH,
  getLocalData,
  saveLocalData,
  isDateString,
  requireAdmin
} = require('../lib/helpers');
const {
  CHANNELS,
  CONTENT_STATUSES,
  oneOf,
  listItems,
  addItem,
  generateDay
} = require('../lib/content');

router.get('/content/items', requireAdmin, (req, res) => {
  const { date, from, to, status, channel } = req.query;
  res.json(listItems({
    date,
    from,
    to,
    status: oneOf(status, CONTENT_STATUSES, null),
    channel: oneOf(channel, CHANNELS, null)
  }));
});

router.post('/content/items', requireAdmin, (req, res) => {
  if (!req.body || (typeof req.body.title !== 'string' && typeof req.body.body !== 'string')) {
    return res.status(400).json({ error: 'title or body is required.' });
  }
  res.status(201).json(addItem(req.body));
});

router.patch('/content/items/:id', requireAdmin, (req, res) => {
  const items = getLocalData(CONTENT_DB_PATH, []);
  const item = items.find((entry) => entry.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Content item not found.' });

  const { title, body, status, channel, hooks, date } = req.body || {};
  if (typeof title === 'string' && title.trim()) item.title = title.trim();
  if (typeof body === 'string') item.body = body;
  if (status !== undefined) {
    item.status = oneOf(status, CONTENT_STATUSES, item.status);
    item.postedAt = item.status === 'posted' ? new Date().toISOString() : null;
  }
  if (channel !== undefined) item.channel = oneOf(channel, CHANNELS, item.channel);
  if (Array.isArray(hooks)) item.hooks = hooks.filter((h) => typeof h === 'string').slice(0, 5);
  if (isDateString(date)) item.date = date;
  // Hand-edited drafts stop being regenerable so the next pack cannot erase them.
  if (item.source === 'generated' && (typeof body === 'string' || typeof title === 'string')) {
    item.source = 'manual';
    item.editedFrom = 'generated';
  }
  item.updatedAt = new Date().toISOString();

  saveLocalData(CONTENT_DB_PATH, items);
  res.json(item);
});

router.delete('/content/items/:id', requireAdmin, (req, res) => {
  const items = getLocalData(CONTENT_DB_PATH, []);
  const remaining = items.filter((entry) => entry.id !== req.params.id);
  if (remaining.length === items.length) return res.status(404).json({ error: 'Content item not found.' });
  saveLocalData(CONTENT_DB_PATH, remaining);
  res.json({ success: true });
});

router.post('/content/generate-day', requireAdmin, (req, res) => {
  const { date, signals } = req.body || {};
  const result = generateDay(date, signals || {});
  res.status(201).json({
    success: true,
    date: result.date,
    created: result.created,
    replacedDrafts: result.replaced,
    signalsUsed: result.signals
  });
});

module.exports = router;
