// Single write door for external tools: the food/workout logging agent, the
// CoS/PA agent posting a content plan, or a chat instruction relayed by a bot.
// Everything here is normalised into the same stores the admin UI reads.
const express = require('express');
const router = express.Router();
const {
  WORKOUT_DB_PATH,
  METRICS_DB_PATH,
  NOTES_DB_PATH,
  getLocalData,
  saveLocalData,
  normalizeDate,
  newId,
  requireAdmin,
  rateLimit,
  logSecurityEvent
} = require('../lib/helpers');
const { appendMeals } = require('../lib/nutrition');
const { addTask } = require('../lib/day');
const { addItem } = require('../lib/content');

const KINDS = ['workout', 'food', 'metric', 'task', 'content', 'note'];

const handlers = {
  workout: (payload, date) => {
    const logs = getLocalData(WORKOUT_DB_PATH, []);
    const entry = {
      id: Date.now(),
      date,
      splitName: typeof payload.splitName === 'string' ? payload.splitName : 'Logged session',
      exercises: Array.isArray(payload.exercises) ? payload.exercises : [],
      descriptionNotes: typeof payload.descriptionNotes === 'string' ? payload.descriptionNotes : '',
      source: payload.source || 'ingest',
      timestamp: new Date().toISOString()
    };
    logs.unshift(entry);
    saveLocalData(WORKOUT_DB_PATH, logs);
    return entry.id;
  },

  food: (payload, date) => {
    const meals = Array.isArray(payload.meals) ? payload.meals : [payload];
    const { record } = appendMeals(date, meals, payload.source || 'ingest');
    return record.id;
  },

  metric: (payload, date) => {
    if (payload.weight === undefined || payload.weight === null || payload.weight === '') {
      throw Object.assign(new Error('metric payload requires weight.'), { status: 400 });
    }
    const metrics = getLocalData(METRICS_DB_PATH, []);
    const num = (value) => (value === undefined || value === null || value === '' ? null : parseFloat(value));
    const entry = {
      id: Date.now(),
      date: `${date}T00:00:00.000Z`,
      weight: parseFloat(payload.weight),
      bodyFat: num(payload.bodyFat),
      bmi: num(payload.bmi),
      visceralFat: num(payload.visceralFat),
      muscleMass: num(payload.muscleMass),
      bmr: num(payload.bmr),
      source: payload.source || 'ingest'
    };
    metrics.unshift(entry);
    saveLocalData(METRICS_DB_PATH, metrics);
    return entry.id;
  },

  task: (payload, date) => {
    if (typeof payload.title !== 'string' || !payload.title.trim()) {
      throw Object.assign(new Error('task payload requires title.'), { status: 400 });
    }
    return addTask({ ...payload, date, source: payload.source || 'ingest' }).id;
  },

  content: (payload, date) => {
    if (typeof payload.title !== 'string' && typeof payload.body !== 'string') {
      throw Object.assign(new Error('content payload requires title or body.'), { status: 400 });
    }
    return addItem({ ...payload, date, source: payload.source || 'manual' }).id;
  },

  note: (payload, date) => {
    const text = typeof payload.text === 'string' ? payload.text : (typeof payload === 'string' ? payload : '');
    if (!text.trim()) {
      throw Object.assign(new Error('note payload requires text.'), { status: 400 });
    }
    const notes = getLocalData(NOTES_DB_PATH, []);
    const entry = {
      id: newId(),
      date,
      text: text.trim(),
      tags: Array.isArray(payload.tags) ? payload.tags.filter((t) => typeof t === 'string') : [],
      source: payload.source || 'ingest',
      createdAt: new Date().toISOString()
    };
    notes.unshift(entry);
    saveLocalData(NOTES_DB_PATH, notes);
    return entry.id;
  }
};

// Generous for a personal agent, tight enough to bound a runaway loop.
const ingestLimiter = rateLimit({ windowMs: 60 * 1000, max: 60, name: 'ingest' });

router.post('/ingest', ingestLimiter, requireAdmin, (req, res) => {
  const { kind, payload, occurredAt } = req.body || {};

  if (!KINDS.includes(kind)) {
    return res.status(400).json({ error: `kind must be one of: ${KINDS.join(', ')}` });
  }
  if (payload === undefined || payload === null) {
    return res.status(400).json({ error: 'payload is required.' });
  }

  // occurredAt accepts a plain date or a full ISO timestamp.
  const date = normalizeDate(typeof occurredAt === 'string' ? occurredAt.split('T')[0] : undefined);

  try {
    const id = handlers[kind](payload, date);
    if (req.actor === 'agent') {
      logSecurityEvent('AGENT_INGEST', req.ip, `kind=${kind} date=${date} id=${id}`);
    }
    return res.status(201).json({ ok: true, kind, id, date });
  } catch (err) {
    const status = err.status || 500;
    if (status === 500) console.error('[ingest] failed:', err);
    return res.status(status).json({ ok: false, kind, error: err.message });
  }
});

router.get('/ingest/kinds', requireAdmin, (req, res) => {
  res.json({ kinds: KINDS });
});

module.exports = router;
