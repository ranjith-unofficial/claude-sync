require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 5000;

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));

// CORS allowlist. Production never reflects arbitrary origins; set CORS_ORIGINS
// to a comma-separated list to override the defaults below.
const DEFAULT_PROD_ORIGINS = ['https://ranjith.tech', 'https://www.ranjith.tech'];
const allowedOrigins = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

const isProduction = process.env.NODE_ENV === 'production';
const corsAllowlist = allowedOrigins.length
  ? allowedOrigins
  : (isProduction ? DEFAULT_PROD_ORIGINS : null);

app.use(cors({
  credentials: true,
  origin: (origin, callback) => {
    // Same-origin and server-to-server calls arrive without an Origin header.
    if (!origin) return callback(null, true);
    if (!corsAllowlist) return callback(null, true); // dev only
    if (corsAllowlist.includes(origin)) return callback(null, true);
    return callback(new Error(`Origin ${origin} is not allowed by CORS.`));
  }
}));

app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Mount modular routers. Personal OS routers go before the shortener so its
// catch-all `/:code` can never shadow an API path.
app.use('/api/admin', require('./routes/admin'));
app.use('/api', require('./routes/home'));
app.use('/api', require('./routes/health'));
app.use('/api', require('./routes/day'));
app.use('/api', require('./routes/content'));
app.use('/api', require('./routes/calendar'));
app.use('/api', require('./routes/ingest'));
app.use('/api', require('./routes/telemetry'));
app.use('/api', require('./routes/lms'));
app.use('/api', require('./routes/invoices'));
app.use('/api', require('./routes/shortener'));
app.use('/', require('./routes/shortener'));

app.get('/api', (req, res) => {
  res.json({ message: 'Ranjith Portfolio Backend API (Modular Server)' });
});

if (require.main === module) {
  require('./lib/helpers').auditEnvironment();
  app.listen(PORT, () => {
    console.log(`Master Security & Backend API Server running on port ${PORT}`);
  });
}

module.exports = app;
